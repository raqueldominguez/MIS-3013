﻿namespace Collections_Min_Max_Avg
{
    internal class List
    {
    }
}